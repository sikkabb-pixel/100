package com.example.timework

import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private fun xmlText(text: String) = text.filter {
    it >= ' ' || it == '\n' || it == '\t' || it == '\r'
}.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

private fun reportSheet(template: String, report: MonthlyReport): String {
    val merges = mutableListOf("A1:H1","A2:A3","B2:D2","E2:G2","H2:H3")
    val data = StringBuilder("<sheetData>")
    var row = 0
    fun begin(height: Int) {
        row++
        data.append("""<row r="$row" ht="$height" customHeight="1">""")
    }
    fun cell(col: Char, style: Int, value: String, number: Boolean = false) {
        val body = if (number) "<v>$value</v>" else
            """<is><t xml:space="preserve">${xmlText(value)}</t></is>"""
        val type = if (number) "n" else "inlineStr"
        data.append("""<c r="$col$row" s="$style" t="$type">$body</c>""")
    }
    fun end() { data.append("</row>") }
    begin(32); cell('A',1,report.title); end()
    begin(20)
    cell('A',2,"วันที่");cell('B',3,"งานปกติ");cell('E',4,otTitle);cell('H',2,"หมายเหตุ");end()
    begin(18)
    for (i in 1..6) cell('A'+i, if(i<=3) 3 else 4, reportHeaders[i])
    end()
    for (day in report.days) {
        val base = when { day.sunday -> 11; day.leave -> 15; else -> 7 }
        val lines = day.note.split('\n').sumOf { maxOf(1,(it.length+37)/38) }
        val minimumHeight = (760 / report.days.size).coerceIn(19, 48)
        begin((17 * lines).coerceIn(minimumHeight,409))
        cell('A', base, day.day.toString(), true)
        if (day.status.isNotBlank()) {
            cell('B',base,day.status)
            merges.add("B$row:G$row")
        } else {
            val values = day.values
            for (i in 1..6) {
                val duration = i == 3 || i == 6
                val parts = values[i].split(':')
                val mins = if (parts.size == 2) {
                    val h = parts[0].toIntOrNull()
                    val m = parts[1].toIntOrNull()
                    if (h != null && m != null) h * 60 + m else null
                } else null
                if (mins != null) cell('A'+i,base + if(duration) 2 else 1,(mins/1440.0).toString(),true)
                else cell('A'+i,base,values[i].ifBlank { "—" })
            }
        }
        cell('H',base+3,day.note);end()
    }
    begin(20)
    for (c in 'A'..'H') {
        val total = when(c) { 'D' -> report.regularTotal; 'G' -> report.otTotal; else -> null }
        if (total == null) cell(c,5,if (c=='A') "รวม" else "")
        else cell(c,6,(total/1440.0).toString(),true)
    }
    end()
    data.append("</sheetData><mergeCells count=\"").append(merges.size).append("\">")
    merges.forEach { data.append("""<mergeCell ref="$it"/>""") }
    data.append("</mergeCells>")
    return template.substringBefore("<sheetData>").replace(Regex("""<dimension ref="[^"]*"/>"""),"""<dimension ref="A1:H$row"/>""") +
        data + template.substringAfter("</sheetData>")
}

internal fun writeReportExcel(report: MonthlyReport, template: InputStream, output: OutputStream) {
    ZipInputStream(template).use { input ->
        ZipOutputStream(output).use { zip ->
            var entry = input.nextEntry
            while (entry != null) {
                zip.putNextEntry(ZipEntry(entry.name))
                if (entry.name == "xl/worksheets/sheet1.xml") {
                    val xml = input.readBytes().toString(Charsets.UTF_8)
                    zip.write(reportSheet(xml,report).toByteArray(Charsets.UTF_8))
                } else input.copyTo(zip)
                zip.closeEntry()
                entry = input.nextEntry
            }
        }
    }
}
