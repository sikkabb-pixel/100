package com.example.timework

import android.app.*
import android.os.Bundle
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Entry(val id: Long, val day: String, val start: String, val end: String, val kind: String, val note: String,
                 val otStart: String = "", val otEnd: String = "")

class Db(ctx: android.content.Context): SQLiteOpenHelper(ctx, "timework.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, start TEXT DEFAULT '', end TEXT DEFAULT '', kind TEXT NOT NULL DEFAULT 'work', note TEXT DEFAULT '', ot_start TEXT DEFAULT '', ot_end TEXT DEFAULT '')")
        db.execSQL("CREATE UNIQUE INDEX idx_day_kind ON entries(day, kind)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if(oldVersion < 2) {
            db.execSQL("ALTER TABLE entries ADD COLUMN ot_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE entries ADD COLUMN ot_end TEXT DEFAULT ''")
        }
    }
    fun all(month: String): List<Entry> {
        val out= mutableListOf<Entry>()
        readableDatabase.rawQuery("SELECT id,day,start,end,kind,note,ot_start,ot_end FROM entries WHERE day LIKE ? ORDER BY day", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) out.add(Entry(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7)))
        }
        return out
    }
    fun one(day:String, kind:String="work"): Entry? {
        readableDatabase.rawQuery("SELECT id,day,start,end,kind,note,ot_start,ot_end FROM entries WHERE day=? AND kind=?", arrayOf(day,kind)).use { c ->
            if(c.moveToFirst()) return Entry(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7))
        }; return null
    }
    fun openShift(): Entry? {
        val sql = """SELECT day FROM entries WHERE kind='work' AND
            ((start<>'' AND end='') OR (ot_start<>'' AND ot_end=''))
            ORDER BY day DESC LIMIT 1"""
        val day = readableDatabase.rawQuery(sql, null).use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
        return day?.let { one(it) }
    }
    fun save(day:String,start:String,end:String,kind:String="work",note:String="") {
        val old=one(day,kind); val v=ContentValues().apply { put("day",day);put("start",start);put("end",end);put("kind",kind);put("note",note) }
        if(old==null) writableDatabase.insert("entries",null,v) else writableDatabase.update("entries",v,"id=?", arrayOf(old.id.toString()))
    }
    fun punch(day:String, field:String, time:String) {
        val e=one(day) ?: run { save(day,"",""); one(day)!! }
        val v=ContentValues().apply { put(field,time) }
        writableDatabase.update("entries",v,"id=?",arrayOf(e.id.toString()))
    }
    fun punchOt(day:String, field:String, time:String) {
        val e=one(day) ?: run { save(day,"",""); one(day)!! }
        val column=if(field=="ot_start") "ot_start" else "ot_end"
        val v=ContentValues().apply { put(column,time) }
        writableDatabase.update("entries",v,"id=?",arrayOf(e.id.toString()))
    }
    fun delete(id:Long) { writableDatabase.delete("entries","id=?",arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private val dateFmt=SimpleDateFormat("yyyy-MM-dd",Locale.US)
    private val monthFmt=SimpleDateFormat("yyyy-MM",Locale.US)
    private var month=monthFmt.format(Date())
    private fun today()=dateFmt.format(Date())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)
    private var otDay: String? = null
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=Db(this)
        month = savedInstanceState?.getString("month") ?: month
        val day = savedInstanceState?.getString("otDay")
        if (day == null) showHome() else showOt(day)
    }
    override fun onRestart() {
        super.onRestart()
        val day = otDay
        if (day == null) showHome() else showOt(day)
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("month", month)
        outState.putString("otDay", otDay)
    }
    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (otDay != null) showHome() else super.onBackPressed() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=16f,bold:Boolean=false): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(0xff172B26.toInt()); if(bold)setTypeface(null,Typeface.BOLD); setPadding(dp(4),dp(7),dp(4),dp(7)) }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply { text=s; setOnClickListener { action() } }
    private fun page(title:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(12),dp(16),dp(16)); setBackgroundColor(0xffF4F7F5.toInt()) }
        val sc=ScrollView(this); sc.addView(root); setContentView(sc)
        root.addView(text(title,23f,true))
    }
    private fun showHome() {
        otDay = null
        page("บันทึกเวลาทำงาน")
        root.addView(text("วันนี้  ${today()}", 15f))
        val shift = db.openShift() ?: db.one(today())
        if (shift == null || shift.start.isBlank() && shift.otStart.isBlank()) {
            root.addView(button("เข้างาน") {
                val instant = Date()
                val day = dateFmt.format(instant)
                if (db.openShift() == null && db.one(day)?.start.isNullOrBlank()) {
                    db.punch(day, "start", timeFmt.format(instant))
                }
                showHome()
            })
        } else {
            root.addView(text("กะวันที่ ${shift.day}   เข้างาน ${shift.start}", 16f, true))
            if (shift.end.isBlank() && shift.otStart.isBlank()) {
                root.addView(button("เลิกงาน") {
                    db.punch(shift.day, "end", timeFmt.format(Date()))
                    showHome()
                })
            } else {
                root.addView(text("เลิกงาน ${shift.end}"))
                root.addView(button("โอทีด่วนจี๋") { showOt(shift.day) })
            }
        }
        root.addView(text("รายงานและจัดการ",18f,true))
        root.addView(button("เลือกเดือน / ดูประวัติ") { chooseMonth() })
        root.addView(button("แก้ไขเวลาย้อนหลัง") { editEntry() })
        root.addView(button("บันทึกวันลา") { addSpecial("leave") })
        root.addView(button("บันทึกวันหยุด") { addSpecial("holiday") })
        root.addView(button("ส่งออก PDF") { exportPdf() })
        root.addView(button("ส่งออก Excel (.xlsx)") { exportExcel() })
        root.addView(text("หมายเหตุ: ข้อมูลเก็บไว้ในโทรศัพท์เครื่องนี้ ไม่ต้องใช้อินเทอร์เน็ต",13f))
        showSummary()
    }
    private fun showOt(day: String) {
        val shift = db.one(day)
        if (shift == null || shift.end.isBlank() && shift.otStart.isBlank()) {
            showHome()
            return
        }
        otDay = day
        page("โอทีด่วนจี๋")
        root.addView(text("กะวันที่ $day   เลิกงานปกติ ${shift.end}"))
        root.addView(text("เริ่มโอที ${shift.otStart.ifBlank { "—" }}   เลิกโอที ${shift.otEnd.ifBlank { "—" }}"))
        root.addView(button("เริ่มโอที") {
            val instant = Date()
            if (dateFmt.format(instant) == day) {
                db.punchOt(day, "ot_start", timeFmt.format(instant))
                showOt(day)
            } else {
                toast("เปลี่ยนวันแล้ว กรุณาตรวจสอบกะที่หน้าหลัก")
                showHome()
            }
        }.apply { isEnabled = shift.otStart.isBlank() && shift.otEnd.isBlank() && day == today() })
        root.addView(button("เลิกโอที") {
            db.punchOt(day, "ot_end", timeFmt.format(Date()))
            showOt(day)
        }.apply { isEnabled = shift.otStart.isNotBlank() && shift.otEnd.isBlank() })
        root.addView(button("กลับหน้าหลัก") { showHome() })
    }
    private fun showSummary() {
        root.addView(text("สรุปเดือน $month",18f,true))
        val list=db.all(month)
        var minutes=0
        var otMinutes=0
        list.filter{it.kind=="work"}.forEach { e ->
            minutes += durationMinutes(e.start,e.end)
            otMinutes += durationMinutes(e.otStart,e.otEnd)
        }
        root.addView(text("วันทำงานที่บันทึก: ${list.count{it.kind=="work" && (it.start.isNotBlank()||it.end.isNotBlank())}} วัน\nชั่วโมงงานปกติ: ${minutes/60} ชม. ${minutes%60} นาที\nโอทีด่วนจี๋: ${otMinutes/60} ชม. ${otMinutes%60} นาที\nวันลา: ${list.count{it.kind=="leave"}} วัน  |  วันหยุด: ${list.count{it.kind=="holiday"}} วัน",15f))
        list.forEach { e ->
            val label=when(e.kind){"leave"->"วันลา";"holiday"->"วันหยุด";else->"ทำงาน"}
            val specialOt = if (e.otStart.isBlank()) "" else
                "\nโอทีด่วนจี๋ ${e.otStart} – ${e.otEnd.ifBlank { "…" }}   •   ${duration(e.otStart, e.otEnd)}"
            val duration=worked(e.start,e.end)
            root.addView(text("${e.day}  •  $label\n${if(e.kind=="work") "เข้า ${e.start.ifBlank{"—"}}   ออก ${e.end.ifBlank{"—"}}   •   $duration$specialOt" else e.note}",14f))
        }
    }
    private fun durationMinutes(a:String,b:String):Int {
        return try {
            if(a.isBlank() || b.isBlank()) return 0
            val x=a.split(":");val y=b.split(":")
            var n=y[0].toInt()*60+y[1].toInt()-x[0].toInt()*60-x[1].toInt()
            if(n<0)n+=1440
            n
        } catch(_:Exception){0}
    }
    private fun duration(a:String,b:String):String {
        val n=durationMinutes(a,b)
        return if(a.isBlank()||b.isBlank()) "ยังไม่ครบ" else "${n/60} ชม. ${n%60} นาที"
    }
    private fun worked(a:String,b:String):String = duration(a,b)
    private fun chooseMonth() {
        val c=Calendar.getInstance()
        DatePickerDialog(this,{_,y,m,_ -> month=String.format(Locale.US,"%04d-%02d",y,m+1); showHome() },c.get(Calendar.YEAR),c.get(Calendar.MONTH),1).show()
    }
    private fun pickDate(on:(String)->Unit) {
        val c=Calendar.getInstance()
        DatePickerDialog(this,{_,y,m,d->on(String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d))},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
    }
    private fun editEntry() {
        pickDate { day ->
            val e=db.one(day) ?: Entry(0,day,"","","work","")
            val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(20),0,dp(20),0) }
            val start=EditText(this).apply { hint="เวลาเข้า HH:mm";setText(e.start) }
            val end=EditText(this).apply { hint="เวลาออก HH:mm";setText(e.end) }
            val otStart=EditText(this).apply { hint="เริ่ม OT HH:mm";setText(e.otStart) }
            val otEnd=EditText(this).apply { hint="สิ้นสุด OT HH:mm";setText(e.otEnd) }
            val note=EditText(this).apply { hint="หมายเหตุ";setText(e.note) }
            box.addView(text(day));box.addView(start);box.addView(end);box.addView(otStart);box.addView(otEnd);box.addView(note)
            AlertDialog.Builder(this).setTitle("แก้ไขเวลาทำงาน").setView(box)
                .setPositiveButton("บันทึก"){_,_-> if(listOf(start.text.toString(),end.text.toString(),otStart.text.toString(),otEnd.text.toString()).all{validTime(it)}) {
                    db.save(day,start.text.toString(),end.text.toString(),"work",note.text.toString())
                    db.punchOt(day,"ot_start",otStart.text.toString()); db.punchOt(day,"ot_end",otEnd.text.toString()); showHome()
                } else toast("กรุณากรอกเวลาในรูปแบบ HH:mm")}
                .setNegativeButton("ยกเลิก",null).show()
        }
    }
    private fun validTime(s:String)=s.isBlank() || Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$").matches(s)
    private fun addSpecial(kind:String) {
        pickDate { day ->
            val label=if(kind=="leave")"วันลา" else "วันหยุด"
            val input=EditText(this).apply { hint="หมายเหตุ (ไม่บังคับ)" }
            AlertDialog.Builder(this).setTitle("บันทึก$label: $day").setView(input)
                .setPositiveButton("บันทึก"){_,_->db.save(day,"","",kind,input.text.toString());showHome()}
                .setNegativeButton("ยกเลิก",null).show()
        }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun createFile(mime:String,name:String,callback:(Uri)->Unit) {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type=mime;putExtra(Intent.EXTRA_TITLE,name) }
        @Suppress("DEPRECATION") startActivityForResult(i, if(mime=="application/pdf") 11 else 12)
    }
    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null)return
        val uri=data.data!!
        try {
            if(requestCode==11) writePdf(uri) else if(requestCode==12) writeExcel(uri)
            toast("ส่งออกไฟล์เรียบร้อย")
        } catch(e:Exception) { toast("ส่งออกไม่สำเร็จ: ${e.message}") }
    }
    private fun exportPdf() { createFile("application/pdf","รายงานเวลาทำงาน_$month.pdf"){} }
    private fun exportExcel() { createFile("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","รายงานเวลาทำงาน_$month.xlsx"){} }
    private fun report() = MonthlyReport(month, db.all(month), ::durationMinutes)

    private fun writePdf(uri: Uri) {
        val stream = contentResolver.openOutputStream(uri) ?: error("เปิดไฟล์ปลายทางไม่ได้")
        stream.use { writeReportPdf(report(), it) }
    }

    private fun writeExcel(uri: Uri) {
        val stream = contentResolver.openOutputStream(uri) ?: error("เปิดไฟล์ปลายทางไม่ได้")
        stream.use { output ->
            assets.open("report-template.xlsx").use { template ->
                writeReportExcel(report(), template, output)
            }
        }
    }
}
