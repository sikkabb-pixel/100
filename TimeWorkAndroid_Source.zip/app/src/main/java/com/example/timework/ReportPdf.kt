package com.example.timework

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextUtils
import android.text.TextPaint
import java.io.OutputStream

internal fun writeReportPdf(report: MonthlyReport, output: OutputStream) {
    val doc = PdfDocument()
    val ink = Color.rgb(26, 43, 48)
    val teal = Color.rgb(205, 234, 228)
    val gold = Color.rgb(255, 229, 167)
    val grey = Color.rgb(233, 239, 240)
    val edges = floatArrayOf(22f, 58f, 111f, 164f, 232f, 285f, 338f, 406f, 573f)
    val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
    var y = 0f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    fun cell(left: Int, right: Int, top: Float, bottom: Float, value: String, bg: Int, bold: Boolean = false) {
        paint.color = bg
        page.canvas.drawRect(edges[left], top, edges[right], bottom, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.6f
        paint.color = Color.rgb(141, 157, 160)
        page.canvas.drawRect(edges[left], top, edges[right], bottom, paint)
        paint.style = Paint.Style.FILL
        paint.color = ink
        paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = if (bottom-top >= 25f) 13f else 10f
        page.canvas.drawText(value, (edges[left]+edges[right])/2, (top+bottom-paint.ascent()-paint.descent())/2, paint)
    }
    fun header() {
        paint.color = ink
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.textSize = 19f
        paint.textAlign = Paint.Align.CENTER
        page.canvas.drawText(report.title, 297.5f, 37f, paint)
        cell(0,1,47f,83f,"วันที่",grey,true)
        cell(1,4,47f,65f,"งานปกติ",teal,true)
        cell(4,7,47f,65f,otTitle,gold,true)
        cell(7,8,47f,83f,"หมายเหตุ",grey,true)
        for (c in 1..6) cell(c,c+1,65f,83f,reportHeaders[c],if (c < 4) teal else gold,true)
        y = 83f
    }
    val rowHeight = (692f / report.days.size).coerceAtMost(50f)
    val notePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 9f }
    try {
        header()
        for (day in report.days) {
            val bg = when {
                day.sunday -> Color.rgb(255, 220, 223)
                day.leave -> Color.rgb(214, 236, 255)
                else -> Color.WHITE
            }
            val bottom = y + rowHeight
            cell(0,1,y,bottom,day.day.toString(),bg,true)
            if (day.status.isNotEmpty()) cell(1,7,y,bottom,day.status,bg,true)
            else for (c in 1..6) cell(c,c+1,y,bottom,day.values[c].ifBlank { "—" },bg)
            cell(7,8,y,bottom,"",bg)
            val lineHeight = notePaint.fontSpacing
            val maxLines = ((rowHeight-3f) / lineHeight).toInt().coerceAtLeast(1)
            val layout = StaticLayout.Builder.obtain(day.note, 0, day.note.length, notePaint, 159)
                .setIncludePad(false).setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
            page.canvas.save()
            page.canvas.clipRect(edges[7]+3,y+1,edges[8]-3,bottom-1)
            page.canvas.translate(edges[7]+4,y+(rowHeight-layout.height)/2)
            layout.draw(page.canvas)
            page.canvas.restore()
            y = bottom
        }
        val totals = listOf("รวม","","",hours(report.regularTotal),"","",hours(report.otTotal),"")
        for (c in totals.indices) cell(c,c+1,y,y+19,totals[c],grey,true)
        paint.color = ink
        paint.textAlign = Paint.Align.RIGHT
        paint.typeface = Typeface.create("serif", Typeface.ITALIC)
        paint.textSize = 13f
        page.canvas.drawText("Bee Paliinjet", edges.last(), 819f, paint)
        doc.finishPage(page)
        doc.writeTo(output)
    } finally {
        doc.close()
    }
}
