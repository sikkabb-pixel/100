package com.example.timework

import java.time.DayOfWeek
import java.time.YearMonth
import java.util.Locale

internal val reportHeaders = listOf("วันที่", "เข้า", "ออก", "รวม ชม.:นาที", "เริ่ม", "เลิก", "รวม ชม.:นาที", "หมายเหตุ")
internal const val otTitle = "โอทีด่วนจี๋"
internal fun hours(minutes: Int) = String.format(Locale.US, "%d:%02d", minutes / 60, minutes % 60)

internal data class ReportDay(
    val day: Int, val sunday: Boolean, val leave: Boolean, val status: String,
    val note: String, val work: Entry?, val regular: Int?, val ot: Int?
) {
    val values get() = listOf(day.toString(), work?.start.orEmpty(), work?.end.orEmpty(),
        regular?.let(::hours).orEmpty(), work?.otStart.orEmpty(), work?.otEnd.orEmpty(),
        ot?.let(::hours).orEmpty(), note)
}

internal class MonthlyReport(month: String, entries: List<Entry>, minutes: (String, String) -> Int) {
    private val period = YearMonth.parse(month)
    private val months = "มกราคม กุมภาพันธ์ มีนาคม เมษายน พฤษภาคม มิถุนายน กรกฎาคม สิงหาคม กันยายน ตุลาคม พฤศจิกายน ธันวาคม".split(" ")
    val title = "รายงานเวลาทำงาน เดือน${months[period.monthValue - 1]} ${period.year + 543}"
    private val byDate = entries.groupBy { it.day }
    private val firstDay = (1..period.lengthOfMonth()).firstOrNull { period.atDay(it).toString() in byDate } ?: 1
    val days = (firstDay..period.lengthOfMonth()).map { day ->
        val date = period.atDay(day)
        val records = byDate[date.toString()].orEmpty()
        val work = records.firstOrNull { it.kind == "work" }
        val hasPunch = work != null && listOf(work.start, work.end, work.otStart, work.otEnd).any { it.isNotBlank() }
        val specials = records.filter { it.kind == "leave" || it.kind == "holiday" }
        fun label(e: Entry) = if (e.kind == "leave") "วันลา" else "หยุด"
        val notes = records.map { e ->
            if (e in specials && (hasPunch || specials.size > 1))
                listOf(label(e), e.note).filter { it.isNotBlank() }.joinToString(" ")
            else e.note
        }.filter { it.isNotBlank() }.joinToString("\n")
        fun elapsed(start: String?, end: String?): Int? =
            if (start.isNullOrBlank() || end.isNullOrBlank()) null else minutes(start, end)
        ReportDay(day, date.dayOfWeek == DayOfWeek.SUNDAY, specials.any { it.kind == "leave" },
            if (hasPunch) "" else specials.joinToString(" / ") { label(it) }, notes, work,
            elapsed(work?.start, work?.end), elapsed(work?.otStart, work?.otEnd))
    }
    val regularTotal = days.sumOf { it.regular ?: 0 }
    val otTotal = days.sumOf { it.ot ?: 0 }
}
